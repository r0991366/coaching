package be.ucll.se.courses.backend.service;

import be.ucll.se.courses.backend.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class UserDetailsServiceImpl {

    private final UserRepository userRepository;

    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserDetailsImpl loadUserByUsername(String username)  {
        return new UserDetailsImpl(userRepository.findByUsername(username).orElseThrow(() -> new IllegalArgumentException(username)));
    }

    public UserDetailsImpl updatePassword(UserDetailsImpl userDetails, String newPassword) {
        final var user = ((UserDetailsImpl) userDetails).user();
        user.setPassword(newPassword);
        return userDetails;
    }
}
